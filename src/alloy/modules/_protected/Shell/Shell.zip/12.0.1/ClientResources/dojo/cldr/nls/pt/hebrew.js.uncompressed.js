define(
"dojo/cldr/nls/pt/hebrew", //begin v1.x content
{
	"dateFormatItem-yM": "MM/yyyy",
	"dateFormatItem-yQ": "yyyy Q",
	"months-standAlone-abbr-leap": "Adar II",
	"dateFormatItem-MMMEd": "E, d 'de' MMM",
	"days-standAlone-wide": [
		"domingo",
		"segunda-feira",
		"terça-feira",
		"quarta-feira",
		"quinta-feira",
		"sexta-feira",
		"sábado"
	],
	"months-format-abbr-leap": "Adar II",
	"quarters-standAlone-abbr": [
		"T1",
		"T2",
		"T3",
		"T4"
	],
	"months-standAlone-abbr": [
		"Tishri",
		"Heshvan",
		"Kislev",
		"Tevet",
		"Shevat",
		"Adar I",
		"Adar",
		"Nisan",
		"Iyar",
		"Sivan",
		"Tamuz",
		"Av",
		"Elul"
	],
	"dateFormatItem-Ed": "E, d",
	"dateFormatItem-yMMM": "MMM 'de' y",
	"days-standAlone-narrow": [
		"D",
		"S",
		"T",
		"Q",
		"Q",
		"S",
		"S"
	],
	"dateFormat-long": "d 'de' MMMM 'de' y",
	"dateFormat-medium": "dd/MM/yyyy",
	"dayPeriods-format-narrow-pm": "p",
	"dateFormatItem-yMd": "dd/MM/yyyy",
	"quarters-standAlone-wide": [
		"1º trimestre",
		"2º trimestre",
		"3º trimestre",
		"4º trimestre"
	],
	"dayPeriods-format-narrow-am": "a",
	"months-standAlone-wide": [
		"Tishri",
		"Heshvan",
		"Kislev",
		"Tevet",
		"Shevat",
		"Adar I",
		"Adar",
		"Nisan",
		"Iyar",
		"Sivan",
		"Tamuz",
		"Av",
		"Elul"
	],
	"dateFormatItem-MMMd": "d 'de' MMM",
	"months-format-abbr": [
		"Tishri",
		"Heshvan",
		"Kislev",
		"Tevet",
		"Shevat",
		"Adar I",
		"Adar",
		"Nisan",
		"Iyar",
		"Sivan",
		"Tamuz",
		"Av",
		"Elul"
	],
	"quarters-format-abbr": [
		"T1",
		"T2",
		"T3",
		"T4"
	],
	"days-format-abbr": [
		"dom",
		"seg",
		"ter",
		"qua",
		"qui",
		"sex",
		"sáb"
	],
	"days-format-narrow": [
		"D",
		"S",
		"T",
		"Q",
		"Q",
		"S",
		"S"
	],
	"dateFormatItem-yMMMd": "d 'de' MMM 'de' y",
	"dateFormatItem-MEd": "E, dd/MM",
	"days-standAlone-short": [
		"dom",
		"seg",
		"ter",
		"qua",
		"qui",
		"sex",
		"sáb"
	],
	"days-standAlone-abbr": [
		"dom",
		"seg",
		"ter",
		"qua",
		"qui",
		"sex",
		"sáb"
	],
	"months-standAlone-wide-leap": "Adar II",
	"dateFormat-short": "dd/MM/yy",
	"dateFormatItem-yMMMEd": "E, d 'de' MMM 'de' y",
	"dateFormat-full": "EEEE, d 'de' MMMM 'de' y",
	"dateFormatItem-Md": "d/M",
	"dateFormatItem-yMEd": "E, dd/MM/yyyy",
	"months-format-wide": [
		"Tishri",
		"Heshvan",
		"Kislev",
		"Tevet",
		"Shevat",
		"Adar I",
		"Adar",
		"Nisan",
		"Iyar",
		"Sivan",
		"Tamuz",
		"Av",
		"Elul"
	],
	"days-format-short": [
		"dom",
		"seg",
		"ter",
		"qua",
		"qui",
		"sex",
		"sáb"
	],
	"quarters-format-wide": [
		"1º trimestre",
		"2º trimestre",
		"3º trimestre",
		"4º trimestre"
	],
	"months-format-wide-leap": "Adar II",
	"days-format-wide": [
		"domingo",
		"segunda-feira",
		"terça-feira",
		"quarta-feira",
		"quinta-feira",
		"sexta-feira",
		"sábado"
	]
}
//end v1.x content
);